angular.module('app', [])
  .controller('GalleryController', function ($scope) {
    $scope.name = 'Galleries';
  });
