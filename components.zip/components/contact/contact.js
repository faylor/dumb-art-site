angular.module('app', [])
  .controller('ContactController', function ($scope) {
    $scope.name = 'Contacter';
  });
